﻿using _5041ProjectIS.Models.Domain;
using _5041ProjectIS.Models.DTOs;
using _5041ProjectIS.Repositories;
using _5041ProjectIS.Repositories.Interface;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace _5041ProjectIS.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductController : ControllerBase
    {
        private readonly IProductRepo _productRepo;
        private readonly ICategoryRepo _categoryRepo;

        public ProductController(IProductRepo productRepo, ICategoryRepo categoryRepo)
        {
            _productRepo = productRepo ?? throw new ArgumentNullException(nameof(productRepo));
            _categoryRepo = categoryRepo ?? throw new ArgumentNullException(nameof(productRepo));
        }

        [HttpGet]
        public async Task<IActionResult> GetProducts()
        {
            var products = await _productRepo.GetAllWithCategoriesAsync();

            if (products == null)
            {
                return NotFound("No products found.");
            }

            var productDtos = new List<ProductDTO>();
            foreach (var product in products)
            {
                productDtos.Add(new ProductDTO
                {
                    Id = product.Id,
                    Name = product.Name,
                    Description = product.Description,
                    Price = product.Price,
                    Quantity = product.Quantity,
                    Categories = MapCategories(product.Categories)
                });
            }

            return Ok(productDtos);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetProduct(int id)
        {
            var product = await _productRepo.GetByIdAsync(id);

            if (product == null)
            {
                return NotFound($"Product with ID {id} not found.");
            }

            var productDto = new ProductDTO
            {
                Id = product.Id,
                Name = product.Name,
                Description = product.Description,
                Price = product.Price,
                Quantity = product.Quantity,
                Categories = MapCategories(product.Categories)
            };

            return Ok(productDto);
        }

        [HttpPost]
        public async Task<IActionResult> CreateProduct([FromBody] CreateProductDTO productDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var categories = new List<Category>();
            foreach (var categoryId in productDto.CategoryIds)
            {
                var category = await _categoryRepo.GetByIdAsync(categoryId);
                if (category != null)
                {
                    categories.Add(category);
                }
                else
                {
                    return BadRequest($"Category with ID {categoryId} not found.");
                }
            }

            var product = new Product
            {
                Name = productDto.Name,
                Description = productDto.Description,
                Price = productDto.Price,
                Quantity = productDto.Quantity,
                Categories = categories 
            };

            var createdProduct = await _productRepo.AddAsync(product);

            var productResult = new ProductDTO
            {
                Id = createdProduct.Id,
                Name = createdProduct.Name,
                Description = createdProduct.Description,
                Price = createdProduct.Price,
                Quantity = createdProduct.Quantity,
                Categories = MapCategories(createdProduct.Categories)
            };

            return CreatedAtAction(nameof(GetProduct), new { id = createdProduct.Id }, productResult);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutProduct(int id, UpdateProductDTO updateProductDTO)
        {
            if (id != updateProductDTO.Id)
            {
                return BadRequest("ID mismatch");
            }

            var productToUpdate = await _productRepo.GetByIdAsync(id);

            if (productToUpdate == null)
            {
                return NotFound();
            }

            if (productToUpdate.Categories == null)
            {
                productToUpdate.Categories = new List<Category>();
            }
            else
            {
                productToUpdate.Categories.Clear();
            }

            var categories = new List<Category>();
            foreach (var categoryId in updateProductDTO.CategoryIds)
            {
                var category = await _categoryRepo.GetByIdAsync(categoryId);
                if (category != null)
                {
                    categories.Add(category);
                }
            }

            productToUpdate.Name = updateProductDTO.Name;
            productToUpdate.Description = updateProductDTO.Description;
            productToUpdate.Price = updateProductDTO.Price;
            productToUpdate.Quantity = updateProductDTO.Quantity;

            foreach (var category in categories)
            {
                productToUpdate.Categories.Add(category);
            }

            await _productRepo.UpdateAsync(productToUpdate);

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var product = await _productRepo.GetByIdAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            await _productRepo.DeleteAsync(id);

            return NoContent();
        }

        private List<CategoryDTO> MapCategories(ICollection<Category> categories)
        {
            var categoryDtos = new List<CategoryDTO>();
            if (categories != null)
            {
                foreach (var category in categories)
                {
                    categoryDtos.Add(new CategoryDTO
                    {
                        Id = category.Id,
                        Name = category.Name,
                        Description = category.Description
                    });
                }
            }
            return categoryDtos;
        }
    }
}
