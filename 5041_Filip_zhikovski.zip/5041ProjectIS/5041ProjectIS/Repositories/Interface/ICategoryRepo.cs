﻿using _5041ProjectIS.Models.Domain;

namespace _5041ProjectIS.Repositories.Interface
{
    public interface ICategoryRepo
    {
        Task<Category> GetByIdAsync (int id);
        Task<List<Category>> GetAllAsync();
        Task<Category> AddAsync (Category category);
        Task<Category> UpdateAsync (Category category);
        Task DeleteAsync (int id);
    }
}
