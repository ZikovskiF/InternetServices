﻿using _5041ProjectIS.Models.Domain;

namespace _5041ProjectIS.Repositories.Interface
{
    public interface IProductRepo
    {
        Task<Product> GetByIdAsync (int id);
        Task<List<Product>> GetAllAsync();
        Task<Product> AddAsync(Product product);
        Task<Product> UpdateAsync (Product product);
        Task DeleteAsync (int id);
        Task<List<Product>> GetAllWithCategoriesAsync();
    }
}
