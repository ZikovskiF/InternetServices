﻿using _5041ProjectIS.Controllers;
using _5041ProjectIS.Models.Domain;
using _5041ProjectIS.Models.DTOs;
using _5041ProjectIS.Repositories.Interface;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

public class CategoryControllerTests
{
    private readonly Mock<ICategoryRepo> _mockCategoryRepo;
    private readonly CategoryController _controller;

    public CategoryControllerTests()
    {
        _mockCategoryRepo = new Mock<ICategoryRepo>();
        _controller = new CategoryController(_mockCategoryRepo.Object);
    }

    [Fact]
    public async Task GetCategories_ReturnsOkResult_WithListOfCategories()
    {

        var categories = new List<Category>
        {
            new Category { Id = 1, Name = "Category1", Description = "Description1" },
            new Category { Id = 2, Name = "Category2", Description = "Description2" }
        };

        _mockCategoryRepo.Setup(repo => repo.GetAllAsync()).ReturnsAsync(categories);

        var result = await _controller.GetCategories();

        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnedCategories = Assert.IsType<List<Category>>(okResult.Value);
        Assert.Equal(2, returnedCategories.Count);
    }

    [Fact]
    public async Task GetCategory_ReturnsOkResult_WithCategory()
    {
        var category = new Category { Id = 1, Name = "Category1", Description = "Description1" };
        _mockCategoryRepo.Setup(repo => repo.GetByIdAsync(1)).ReturnsAsync(category);

        var result = await _controller.GetCategory(1);

        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnedCategory = Assert.IsType<Category>(okResult.Value);
        Assert.Equal(1, returnedCategory.Id);
    }

    [Fact]
    public async Task GetCategory_ReturnsNotFound_WhenCategoryDoesNotExist()
    {
        _mockCategoryRepo.Setup(repo => repo.GetByIdAsync(1)).ReturnsAsync((Category)null);

        var result = await _controller.GetCategory(1);

        Assert.IsType<NotFoundResult>(result.Result);
    }

    [Fact]
    public async Task PostCategory_ReturnsCreatedAtActionResult_WhenCategoryIsCreated()
    {
        var createCategoryDTO = new CreateCategoryDTO { Name = "Category1", Description = "Description1" };
        var category = new Category { Id = 1, Name = "Category1", Description = "Description1" };

        _mockCategoryRepo.Setup(repo => repo.AddAsync(It.IsAny<Category>())).ReturnsAsync(category);

        var result = await _controller.PostCategory(createCategoryDTO);

        var createdAtActionResult = Assert.IsType<CreatedAtActionResult>(result.Result);
        var returnedCategory = Assert.IsType<Category>(createdAtActionResult.Value);
        Assert.Equal(1, returnedCategory.Id);
    }

    [Fact]
    public async Task PutCategory_ReturnsNoContent_WhenCategoryIsUpdated()
    {
        var updateCategoryDTO = new UpdateCategoryDTO { Id = 1, Name = "UpdatedCategory", Description = "UpdatedDescription" };
        var category = new Category { Id = 1, Name = "Category1", Description = "Description1" };

        _mockCategoryRepo.Setup(repo => repo.GetByIdAsync(1)).ReturnsAsync(category);

        var result = await _controller.PutCategory(1, updateCategoryDTO);
        Assert.IsType<NoContentResult>(result);
    }

    [Fact]
    public async Task PutCategory_ReturnsBadRequest_WhenIdMismatch()
    {
        var updateCategoryDTO = new UpdateCategoryDTO { Id = 1, Name = "UpdatedCategory", Description = "UpdatedDescription" };

        var result = await _controller.PutCategory(2, updateCategoryDTO);

        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal("ID mismatch", badRequestResult.Value);
    }

    [Fact]
    public async Task PutCategory_ReturnsNotFound_WhenCategoryDoesNotExist()
    {
        var updateCategoryDTO = new UpdateCategoryDTO { Id = 1, Name = "UpdatedCategory", Description = "UpdatedDescription" };

        _mockCategoryRepo.Setup(repo => repo.GetByIdAsync(1)).ReturnsAsync((Category)null);

        var result = await _controller.PutCategory(1, updateCategoryDTO);

        Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public async Task DeleteCategory_ReturnsNoContent_WhenCategoryIsDeleted()
    {
        var category = new Category { Id = 1, Name = "Category1", Description = "Description1" };

        _mockCategoryRepo.Setup(repo => repo.GetByIdAsync(1)).ReturnsAsync(category);
        _mockCategoryRepo.Setup(repo => repo.DeleteAsync(1)).Returns(Task.CompletedTask);

        var result = await _controller.DeleteCategory(1);

        Assert.IsType<NoContentResult>(result);
    }

    [Fact]
    public async Task DeleteCategory_ReturnsNotFound_WhenCategoryDoesNotExist()
    {
        _mockCategoryRepo.Setup(repo => repo.GetByIdAsync(1)).ReturnsAsync((Category)null);

        var result = await _controller.DeleteCategory(1);

        Assert.IsType<NotFoundResult>(result);
    }
}
