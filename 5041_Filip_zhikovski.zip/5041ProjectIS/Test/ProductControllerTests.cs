﻿using _5041ProjectIS.Controllers;
using _5041ProjectIS.Models.Domain;
using _5041ProjectIS.Models.DTOs;
using _5041ProjectIS.Repositories.Interface;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

public class ProductControllerTests
{
    private readonly Mock<IProductRepo> _mockProductRepo;
    private readonly Mock<ICategoryRepo> _mockCategoryRepo;
    private readonly ProductController _controller;

    public ProductControllerTests()
    {
        _mockProductRepo = new Mock<IProductRepo>();
        _mockCategoryRepo = new Mock<ICategoryRepo>();
        _controller = new ProductController(_mockProductRepo.Object, _mockCategoryRepo.Object);
    }

    [Fact]
    public async Task CreateProduct_ReturnsCreatedAtActionResult_WhenProductIsValid()
    {

        var productDto = new CreateProductDTO
        {
            Name = "Test Product",
            Description = "Test Description",
            Price = 10,
            Quantity = 5,
            CategoryIds = new List<int> { 1, 2 }
        };

        var categories = new List<Category>
        {
            new Category { Id = 1, Name = "Category1", Description = "Description1" },
            new Category { Id = 2, Name = "Category2", Description = "Description2" }
        };

        var createdProduct = new Product
        {
            Id = 1,
            Name = productDto.Name,
            Description = productDto.Description,
            Price = productDto.Price,
            Quantity = productDto.Quantity,
            Categories = categories
        };

        _mockCategoryRepo.Setup(repo => repo.GetByIdAsync(1)).ReturnsAsync(categories[0]);
        _mockCategoryRepo.Setup(repo => repo.GetByIdAsync(2)).ReturnsAsync(categories[1]);
        _mockProductRepo.Setup(repo => repo.AddAsync(It.IsAny<Product>())).ReturnsAsync(createdProduct);


        var result = await _controller.CreateProduct(productDto);

 
        var createdAtActionResult = Assert.IsType<CreatedAtActionResult>(result);
        var returnedProduct = Assert.IsType<ProductDTO>(createdAtActionResult.Value);
        Assert.Equal(createdProduct.Id, returnedProduct.Id);
        Assert.Equal(createdProduct.Name, returnedProduct.Name);
        Assert.Equal(createdProduct.Description, returnedProduct.Description);
        Assert.Equal(createdProduct.Price, returnedProduct.Price);
        Assert.Equal(createdProduct.Quantity, returnedProduct.Quantity);
        Assert.Equal(2, returnedProduct.Categories.Count);
    }

    [Fact]
    public async Task CreateProduct_ReturnsBadRequest_WhenCategoryNotFound()
    {
  
        var productDto = new CreateProductDTO
        {
            Name = "Test Product",
            Description = "Test Description",
            Price = 10,
            Quantity = 5,
            CategoryIds = new List<int> { 1, 2 }
        };

        _mockCategoryRepo.Setup(repo => repo.GetByIdAsync(1)).ReturnsAsync(new Category { Id = 1, Name = "Category1", Description = "Description1" });
        _mockCategoryRepo.Setup(repo => repo.GetByIdAsync(2)).ReturnsAsync((Category)null);

    
        var result = await _controller.CreateProduct(productDto);

      
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal("Category with ID 2 not found.", badRequestResult.Value);
    }

    [Fact]
    public async Task PutProduct_ReturnsNoContent_WhenProductIsUpdated()
    {
  
        var updateProductDto = new UpdateProductDTO
        {
            Id = 1,
            Name = "Updated Product",
            Description = "Updated Description",
            Price = 15,
            Quantity = 10,
            CategoryIds = new List<int> { 1, 2 }
        };

        var product = new Product
        {
            Id = 1,
            Name = "Existing Product",
            Description = "Existing Description",
            Price = 10,
            Quantity = 5,
            Categories = new List<Category>()
        };

        var categories = new List<Category>
        {
            new Category { Id = 1, Name = "Category1", Description = "Description1" },
            new Category { Id = 2, Name = "Category2", Description = "Description2" }
        };

        _mockProductRepo.Setup(repo => repo.GetByIdAsync(1)).ReturnsAsync(product);
        _mockCategoryRepo.Setup(repo => repo.GetByIdAsync(1)).ReturnsAsync(categories[0]);
        _mockCategoryRepo.Setup(repo => repo.GetByIdAsync(2)).ReturnsAsync(categories[1]);
        _mockProductRepo.Setup(repo => repo.UpdateAsync(It.IsAny<Product>())).ReturnsAsync(product);

 
        var result = await _controller.PutProduct(1, updateProductDto);

        Assert.IsType<NoContentResult>(result);
        _mockProductRepo.Verify(repo => repo.UpdateAsync(It.Is<Product>(p => p.Id == 1 && p.Name == updateProductDto.Name && p.Description == updateProductDto.Description)), Times.Once);
    }

    [Fact]
    public async Task PutProduct_ReturnsBadRequest_WhenIdMismatch()
    {

        var updateProductDto = new UpdateProductDTO
        {
            Id = 1,
            Name = "Updated Product",
            Description = "Updated Description",
            Price = 15,
            Quantity = 10,
            CategoryIds = new List<int> { 1, 2 }
        };

        var result = await _controller.PutProduct(2, updateProductDto);

        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal("ID mismatch", badRequestResult.Value);
    }

    [Fact]
    public async Task PutProduct_ReturnsNotFound_WhenProductNotFound()
    {
  
        var updateProductDto = new UpdateProductDTO
        {
            Id = 1,
            Name = "Updated Product",
            Description = "Updated Description",
            Price = 15,
            Quantity = 10,
            CategoryIds = new List<int> { 1, 2 }
        };

        _mockProductRepo.Setup(repo => repo.GetByIdAsync(1)).ReturnsAsync((Product)null);

    
        var result = await _controller.PutProduct(1, updateProductDto);

  
        Assert.IsType<NotFoundResult>(result);
    }
}
